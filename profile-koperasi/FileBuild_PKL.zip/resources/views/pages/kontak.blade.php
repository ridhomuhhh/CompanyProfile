@extends('layouts.app')

@section('content')
  <section class="container my-5">
    <div class="row">
      <div class="col text-center">
        <h1 class="display-4 fw-bold">Hubungi Kami</h1>
        <p class="lead text-muted">Kami siap membantu Anda.</p>
      </div>
    </div>
  </section>

  <section class="container mb-5 pb-5">
    <div class="row g-5">
      <div class="col-lg-5">
        <h3 class="fw-bold mb-4">Informasi Kontak</h3>

        <div class="contact-info-box p-4 rounded bg-light shadow-sm h-100">
          <ul class="list-unstyled">
            <li class="d-flex align-items-start mb-3">
              <i class="bi bi-geo-alt-fill fs-4 text-primary me-3"></i>
              <div>
                <h5 class="fw-bold">Alamat</h5>
                <p class="mb-0">{{ $kontaks?->alamat ?? 'Isi dengan alamat kantor' }}</p>
              </div>
            </li>
            <li class="d-flex align-items-start mb-3">
              <i class="bi bi-telephone-fill fs-4 text-primary me-3"></i>
              <div>
                <h5 class="fw-bold">Telepon</h5>
                <p class="mb-0">{{ $kontaks?->telepon ?? 'Isi dengan nomor telepon' }}</p>
              </div>
            </li>
            <li class="d-flex align-items-start mb-3">
              <i class="bi bi-envelope-fill fs-4 text-primary me-3"></i>
              <div>
                <h5 class="fw-bold">Email</h5>
                <p class="mb-0">{{ $kontaks?->email ?? 'Isi dengan email kantor' }}</p>
              </div>
            </li>
            <li class="d-flex align-items-start">
              <i class="bi bi-clock-fill fs-4 text-primary me-3"></i>
              <div>
                <h5 class="fw-bold">Jam Operasional</h5>
                <p class="mb-0">Senin - Jumat: {{ $kontaks?->jam_operasional ?? 'Isi dengan jam operasional' }} WIB</p>
              </div>
            </li>
          </ul>
        </div>
      </div>

      <div class="col-lg-7">
        <h3 class="fw-bold mb-4">Lokasi Kami</h3>

        <div class="ratio ratio-16x9 rounded shadow h-100">
          <iframe
            src="{{ $kontaks?->maps ?? 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3957.349823765269!2d112.71498477405973!3d-7.314541671919254!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2dd7fb7dc60d834b%3A0x2e8dc10cbef60c16!2sPT.%20Temprina%20Media%20Grafika%20(Packaging)!5e0!3m2!1sen!2sid!4v1768171814925!5m2!1sen!2sid"' }}"
            style="border: 0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade">
          </iframe>
        </div>
      </div>

    </div>
  </section>
@endsection
